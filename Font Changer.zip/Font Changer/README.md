# **If The Script Crashes Please Make Sure:**



You Have Installed Python 3.9 Or Later



You Placed ONE file in the folder

